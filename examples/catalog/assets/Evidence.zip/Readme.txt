Synthetic workshop evidence. Tax remains unknown.
